import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import { fileURLToPath } from 'url';

const { Pool } = pg;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-me';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '../public')));

const sign = (u) => jwt.sign({ sub: u.id, role: u.role }, JWT_SECRET, { expiresIn: '8h' });
function auth(req,res,next){
  const h=req.headers.authorization||''; const token=h.startsWith('Bearer ')?h.slice(7):null;
  if(!token) return res.status(401).json({error:'Authentification requise'});
  try { req.user=jwt.verify(token,JWT_SECRET); next(); } catch { return res.status(401).json({error:'Session invalide'}); }
}
function roles(...allowed){ return (req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({error:'Accès refusé'}); }

app.get('/api/health', async (_req,res)=>{ try { await pool.query('SELECT 1'); res.json({ok:true,service:'SoinsChezVous'}); } catch { res.status(503).json({ok:false}); } });

app.post('/api/auth/register', async (req,res)=>{
  const {email,password,role='PATIENT',firstName,lastName,city,postalCode}=req.body;
  if(!email||!password||password.length<10||!firstName||!lastName||!city||!postalCode) return res.status(400).json({error:'Champs obligatoires ou mot de passe trop court'});
  if(!['PATIENT','NURSE'].includes(role)) return res.status(400).json({error:'Rôle invalide'});
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const hash=await bcrypt.hash(password,12);
    const u=await client.query('INSERT INTO users(email,password_hash,role) VALUES($1,$2,$3) RETURNING id,email,role',[email.toLowerCase(),hash,role]);
    if(role==='PATIENT') await client.query('INSERT INTO patient_profiles(user_id,first_name,last_name,city,postal_code) VALUES($1,$2,$3,$4,$5)',[u.rows[0].id,firstName,lastName,city,postalCode]);
    else await client.query('INSERT INTO nurse_profiles(user_id,first_name,last_name,city,postal_code) VALUES($1,$2,$3,$4,$5)',[u.rows[0].id,firstName,lastName,city,postalCode]);
    await client.query('COMMIT'); res.status(201).json({user:u.rows[0],token:sign(u.rows[0])});
  } catch(e){ await client.query('ROLLBACK'); res.status(e.code==='23505'?409:500).json({error:e.code==='23505'?'Email déjà utilisé':'Erreur serveur'}); } finally { client.release(); }
});

app.post('/api/auth/login', async (req,res)=>{
  const {email,password}=req.body; if(!email||!password) return res.status(400).json({error:'Email et mot de passe requis'});
  const r=await pool.query('SELECT id,email,role,password_hash FROM users WHERE email=$1',[email.toLowerCase()]);
  if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash))) return res.status(401).json({error:'Identifiants incorrects'});
  const {password_hash,...u}=r.rows[0]; res.json({user:u,token:sign(u)});
});

app.get('/api/nurses', async (req,res)=>{
  const city=(req.query.city||'').trim(); const postal=(req.query.postalCode||'').trim(); const specialty=(req.query.specialty||'').trim();
  const vals=[]; const where=['verified=true'];
  if(city){vals.push(`%${city}%`);where.push(`city ILIKE $${vals.length}`)}
  if(postal){vals.push(`${postal}%`);where.push(`postal_code LIKE $${vals.length}`)}
  if(specialty){vals.push(specialty);where.push(`$${vals.length}=ANY(specialties)`)}
  const q=`SELECT id,first_name,last_name,city,postal_code,specialties,intervention_radius_km FROM nurse_profiles WHERE ${where.join(' AND ')} ORDER BY last_name LIMIT 50`;
  const r=await pool.query(q,vals); res.json(r.rows);
});

app.post('/api/requests',auth,roles('PATIENT'),async(req,res)=>{
  const {city,postalCode,careType,requestedAt}=req.body;
  if(!city||!postalCode||!careType) return res.status(400).json({error:'Ville, code postal et type de soins requis'});
  const r=await pool.query('INSERT INTO care_requests(patient_id,city,postal_code,care_type,requested_at) VALUES($1,$2,$3,$4,$5) RETURNING *',[req.user.sub,city,postalCode,careType,requestedAt||null]);
  res.status(201).json(r.rows[0]);
});

app.get('/api/requests',auth,async(req,res)=>{
  let q='SELECT * FROM care_requests WHERE patient_id=$1 ORDER BY created_at DESC'; let p=[req.user.sub];
  if(req.user.role==='NURSE'){q='SELECT * FROM care_requests WHERE nurse_id=$1 OR (nurse_id IS NULL AND status=\'PENDING\') ORDER BY created_at DESC';}
  if(req.user.role==='ADMIN'){q='SELECT * FROM care_requests ORDER BY created_at DESC LIMIT 200';p=[];}
  const r=await pool.query(q,p); res.json(r.rows);
});

app.patch('/api/requests/:id',auth,roles('NURSE','ADMIN'),async(req,res)=>{
  const {status}=req.body; if(!['ACCEPTED','REFUSED','COMPLETED','CANCELLED'].includes(status)) return res.status(400).json({error:'Statut invalide'});
  let r;
  if(req.user.role==='NURSE'&&status==='ACCEPTED') r=await pool.query('UPDATE care_requests SET status=$1,nurse_id=$2 WHERE id=$3 AND (nurse_id=$2 OR nurse_id IS NULL) RETURNING *',[status,req.user.sub,req.params.id]);
  else r=await pool.query('UPDATE care_requests SET status=$1 WHERE id=$2 RETURNING *',[status,req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:'Demande introuvable'}); res.json(r.rows[0]);
});

app.get('/api/admin/summary',auth,roles('ADMIN'),async(_req,res)=>{
  const r=await pool.query(`SELECT (SELECT count(*) FROM users WHERE role='PATIENT') patients,(SELECT count(*) FROM users WHERE role='NURSE') nurses,(SELECT count(*) FROM care_requests) requests,(SELECT count(*) FROM nurse_profiles WHERE verified=true) verified_nurses`); res.json(r.rows[0]);
});

app.get('*',(_req,res)=>res.sendFile(path.join(__dirname,'../public/index.html')));
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`SoinsChezVous listening on :${port}`));
