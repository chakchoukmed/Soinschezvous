CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK (role IN ('PATIENT','NURSE','ADMIN')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nurse_profiles (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 registration_number TEXT,
 city TEXT NOT NULL, postal_code TEXT NOT NULL,
 intervention_radius_km INTEGER NOT NULL DEFAULT 10,
 specialties TEXT[] NOT NULL DEFAULT '{}',
 verified BOOLEAN NOT NULL DEFAULT false,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS patient_profiles (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 city TEXT NOT NULL, postal_code TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS care_requests (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 patient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 nurse_id UUID REFERENCES users(id) ON DELETE SET NULL,
 city TEXT NOT NULL, postal_code TEXT NOT NULL,
 care_type TEXT NOT NULL,
 requested_at TIMESTAMPTZ,
 status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','ACCEPTED','REFUSED','CANCELLED','COMPLETED')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS nurse_city_idx ON nurse_profiles(city);
CREATE INDEX IF NOT EXISTS nurse_postal_idx ON nurse_profiles(postal_code);
CREATE INDEX IF NOT EXISTS requests_status_idx ON care_requests(status);
