# SoinsChezVous V3 — base full-stack

## Démarrage local
1. Copier `.env.example` vers `.env` et modifier `JWT_SECRET`.
2. Installer les dépendances: `npm install`.
3. Créer PostgreSQL et exécuter `db/schema.sql`.
4. Lancer: `npm start`.
5. Ouvrir `http://localhost:3000`.

## Docker
Modifier les mots de passe/secrets dans `docker-compose.yml`, puis `docker compose up -d --build`.

## Important
Cette version est une base technique de développement. Ne pas y saisir de vraies données de santé avant validation juridique, RGPD et hébergement adapté (notamment HDS lorsque le périmètre réglementaire l'exige). Le paiement/commissionnement n'est volontairement pas implémenté.
