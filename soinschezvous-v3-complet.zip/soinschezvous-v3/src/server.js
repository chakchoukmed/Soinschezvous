import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const app = express();
const port = Number(process.env.PORT || 3000);
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) throw new Error('JWT_SECRET (32+ chars) is required');

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'1mb'}));
app.use(cookieParser());
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
app.use(express.static('public'));

const auth = (req,res,next)=>{try{const t=req.cookies.scv_session;if(!t)return res.status(401).json({error:'Non authentifié'});req.user=jwt.verify(t,secret);next()}catch{return res.status(401).json({error:'Session invalide'})}};
const role = r => (req,res,next)=> req.user?.role===r ? next() : res.status(403).json({error:'Accès interdit'});
const safeUser={id:true,email:true,firstName:true,lastName:true,phone:true,role:true,createdAt:true};

app.get('/api/health',(_,res)=>res.json({ok:true,service:'SoinsChezVous',version:'3.0'}));
app.post('/api/auth/register',async(req,res)=>{try{const s=z.object({email:z.string().email(),password:z.string().min(10),firstName:z.string().min(1),lastName:z.string().min(1),phone:z.string().min(6).optional(),role:z.enum(['PATIENT','INFIRMIER'])}).parse(req.body);const email=s.email.toLowerCase();if(await prisma.user.findUnique({where:{email}}))return res.status(409).json({error:'Email déjà utilisé'});const hash=await bcrypt.hash(s.password,12);const u=await prisma.user.create({data:{email,passwordHash:hash,firstName:s.firstName,lastName:s.lastName,phone:s.phone,role:s.role,patientProfile:s.role==='PATIENT'?{create:{}}:undefined,nurseProfile:s.role==='INFIRMIER'?{create:{}}:undefined},select:safeUser});res.status(201).json(u)}catch(e){res.status(400).json({error:'Données invalides'})}});
app.post('/api/auth/login',async(req,res)=>{const s=z.object({email:z.string().email(),password:z.string()}).safeParse(req.body);if(!s.success)return res.status(400).json({error:'Données invalides'});const u=await prisma.user.findUnique({where:{email:s.data.email.toLowerCase()}});if(!u||!(await bcrypt.compare(s.data.password,u.passwordHash)))return res.status(401).json({error:'Identifiants invalides'});const token=jwt.sign({id:u.id,role:u.role},secret,{expiresIn:'8h'});res.cookie('scv_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:28800000});res.json({...u, passwordHash:undefined})});
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('scv_session');res.status(204).end()});
app.get('/api/me',auth,async(req,res)=>res.json(await prisma.user.findUnique({where:{id:req.user.id},select:{...safeUser,nurseProfile:true,patientProfile:true}})));
app.patch('/api/nurse/profile',auth,role('INFIRMIER'),async(req,res)=>{const s=z.object({bio:z.string().max(1000).optional(),rpps:z.string().max(30).optional(),professionalNumber:z.string().max(50).optional(),communes:z.array(z.string()).max(100).optional(),services:z.array(z.string()).max(30).optional(),available:z.boolean().optional()}).parse(req.body);const p=await prisma.nurseProfile.update({where:{userId:req.user.id},data:s});res.json(p)});
app.get('/api/nurses',async(req,res)=>{const city=String(req.query.city||'').trim();const service=String(req.query.service||'').trim();const where={verification:'VERIFIED',available:true,...(city?{communes:{has:city}}:{}),...(service?{services:{has:service}}:{})};const nurses=await prisma.nurseProfile.findMany({where,include:{user:{select:{id:true,firstName:true,lastName:true}}},take:50});res.json(nurses)});
app.post('/api/requests',auth,role('PATIENT'),async(req,res)=>{const s=z.object({service:z.string().min(1).max(120),address:z.string().min(3).max(300),postalCode:z.string().min(4).max(10),city:z.string().min(1).max(120),requestedAt:z.coerce.date(),notes:z.string().max(1000).optional(),nurseId:z.string().optional()}).parse(req.body);const p=await prisma.patientProfile.findUnique({where:{userId:req.user.id}});if(!p)return res.status(400).json({error:'Profil patient absent'});const r=await prisma.careRequest.create({data:{...s,patientId:p.id}});res.status(201).json(r)});
app.get('/api/requests',auth,async(req,res)=>{const where=req.user.role==='PATIENT'?{patient:{userId:req.user.id}}:req.user.role==='INFIRMIER'?{nurse:{userId:req.user.id}}:{};res.json(await prisma.careRequest.findMany({where,orderBy:{createdAt:'desc'},include:{patient:{include:{user:{select:{firstName:true,lastName:true,phone:true}}}},nurse:{include:{user:{select:{firstName:true,lastName:true}}}}}}))});
app.patch('/api/requests/:id',auth,role('INFIRMIER'),async(req,res)=>{const s=z.object({status:z.enum(['ACCEPTED','DECLINED','COMPLETED','CANCELLED'])}).parse(req.body);const n=await prisma.nurseProfile.findUnique({where:{userId:req.user.id}});if(!n)return res.status(404).json({error:'Profil infirmier absent'});const r=await prisma.careRequest.updateMany({where:{id:req.params.id,nurseId:n.id},data:{status:s.status}});res.json({updated:r.count})});
app.get('*',(req,res)=>res.sendFile(process.cwd()+'/public/index.html'));
app.listen(port,()=>console.log(`SoinsChezVous v3 listening on :${port}`));
