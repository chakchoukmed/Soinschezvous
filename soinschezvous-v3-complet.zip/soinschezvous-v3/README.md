# SoinsChezVous V3 — plateforme nationale

Version de travail destinée à un déploiement professionnel après audit et configuration.

## Fonctionnalités
- Site public France entière
- Recherche de profils infirmiers vérifiés
- Comptes Patient / Infirmier
- Authentification par session HTTP-only
- Demandes de soins et statuts
- Profil infirmier et disponibilités
- Espace personnel responsive
- PostgreSQL + Prisma
- Helmet + rate limiting
- Docker

## Démarrage local
1. Copier `.env.example` vers `.env` et définir un secret JWT aléatoire de 32+ caractères.
2. Installer les dépendances : `npm install`
3. Générer Prisma : `npm run prisma:generate`
4. Déployer les migrations : `npm run prisma:migrate`
5. Lancer : `npm start`

## Mise en production
- Utiliser un PostgreSQL managé/hautement sécurisé.
- Ne jamais conserver les mots de passe ou secrets dans Git.
- Activer HTTPS et les sauvegardes chiffrées.
- Faire réaliser l'analyse RGPD/AIPD et les vérifications contractuelles nécessaires.
- Si des données de santé à caractère personnel entrent dans le périmètre de l'article L.1111-8, sélectionner un hébergeur conforme aux exigences HDS applicables.
- Faire auditer l'authentification, les autorisations, les journaux, les sauvegardes et les flux avant ouverture au public.
- Le modèle commercial et la rémunération de la plateforme doivent être validés par un conseil juridique spécialisé en droit de la santé avant activation.

## Limites actuelles
Cette V3 ne comprend pas encore : paiement réel, SMS/email transactionnels, chiffrement applicatif spécialisé des données sensibles, KYC/RPPS automatisé, AIPD, signature de contrats, monitoring de production, CI/CD, ou validation HDS. Ces éléments doivent être ajoutés et audités avant une mise en service réelle.
